/** Automatically generated file. DO NOT MODIFY */
package me.sami.awesomeprofilemanager;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}