package me.sami.awesomeprofilemanager;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.Toast;

public class FirstActivity extends Activity implements SensorEventListener {

	private TextView xText, yText, zText;
	private Button generalB, vibrateB, silentB;
	private RadioGroup radioG;
	private Sensor mySensor;
	private SensorManager sensorManager;
	private int checked;
	private int flag=0;
	AudioManager audioManager;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_first);
	}


	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		
		// Accelerometer
		sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		mySensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		sensorManager.registerListener(this, mySensor, SensorManager.SENSOR_DELAY_NORMAL);
		
		xText = (TextView) findViewById(R.id.textX);
		yText = (TextView) findViewById(R.id.textY);
		zText = (TextView) findViewById(R.id.textZ);  
		
		// Profile Manager
		audioManager = (AudioManager) getSystemService(getApplicationContext().AUDIO_SERVICE);
		
		radioG = (RadioGroup) findViewById(R.id.radioGroup);
		generalB = (Button) findViewById(R.id.buttonGeneral);
		vibrateB = (Button) findViewById(R.id.buttonVibrate);
		silentB = (Button) findViewById(R.id.buttonSilent);
		
		
		
		radioG.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				// TODO Auto-generated method stub
				checked = radioG.indexOfChild(findViewById(checkedId));
				switch(checked) {
				case 1:
					flag = 1;
					generalB.setVisibility(View.INVISIBLE);
					vibrateB.setVisibility(View.INVISIBLE);
					silentB.setVisibility(View.INVISIBLE);
					break;
					
				case 2:
					flag = 0;
					generalB.setVisibility(View.VISIBLE);
					vibrateB.setVisibility(View.VISIBLE);
					silentB.setVisibility(View.VISIBLE);
					break;
					
				default:
					break;
				}
			}
		});
		
		generalB.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
				Toast.makeText(getBaseContext(), "General Mode activated", Toast.LENGTH_LONG).show();
			}
		});
		
		vibrateB.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						audioManager.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
						Toast.makeText(getBaseContext(), "Vibration Mode activated", Toast.LENGTH_LONG).show();
					}
				});

		silentB.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				audioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
				Toast.makeText(getBaseContext(), "Silent Mode activated", Toast.LENGTH_LONG).show();
			}
		});
		
	}
	

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub
		// Not in use
	}


	@Override
	public void onSensorChanged(SensorEvent event) {
		// TODO Auto-generated method stub
		xText.setText("X: " + event.values[0]);
		yText.setText("Y: " + event.values[1]);
		zText.setText("Z: " + event.values[2]);
		
		if(flag == 1) {
			if(event.values[2] > 8.5 && event.values[2] < 11.0) {
				audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
			} else if (event.values[2] < -8.5 && event.values[2] > -11.0) {
				audioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
			} else {
				audioManager.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
			}
		}
	}
	
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
	}
	
	
}
